import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-control-sidebar',
  templateUrl: './admin-control-sidebar.component.html',
  styleUrls: ['./admin-control-sidebar.component.css']
})
export class AdminControlSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
